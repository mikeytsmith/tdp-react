const Person = (props) => {
    return( 
    <p>This is {props.name}, they are from {props.city} </p>)
}
export default Person;