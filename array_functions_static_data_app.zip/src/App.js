import './App.css';
import Content from './staticData/content';
import SubContent from './staticData/subComponent';
import LoginControl from './staticData/LoginControl';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <LoginControl/>
      </header>

      <Content/>
      <SubContent/>
    </div>
  );
}

export default App;
