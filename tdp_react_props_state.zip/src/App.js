
import logo from './logo.svg';
import './App.css';
import Heading from './Heading';
import Form from './form';
import AddressApp from './address';
import Dice from './diceRoll';
import Header from './Header';
import Footer from './Footer';
import PropComp from './PropsPractise';
import ComponentWithProps from './ComponentWithProps';
import Counter from './components/state/counter';
import Converter from './components/state/Converter';
import MilesAhead from './components/state/MilesAhead';
import UserDetails from './components/state/UserDetails';
import Car from './components/state/car';
import ProductTable from './components/state/ProductTable';
import FilterableList from './components/state/FilterableList';

function App() {
  return (
    <div className="App">
          
          <Header/>
          <img src={logo} className="App-logo" alt="logo" />
          <Heading/>
          <Form/>
          <Form/>
          <PropComp/>
          <AddressApp/>
          <Dice/>
          <ComponentWithProps name="Michael" age={25} specialism="TDP"/>
          <ComponentWithProps name="Jess" age={25} specialism="Dogs"/>
          <Counter/>
          <br></br>
          <Converter/>
          <br/>
          <MilesAhead/> 
          <br/>
          <UserDetails/>
          <br/>
          <Car/>
          <ProductTable/>
          <br/>
          <FilterableList/>
          <Footer/>

    </div>
    
  );
}

export default App;

