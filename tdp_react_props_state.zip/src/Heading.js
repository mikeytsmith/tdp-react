const Heading = () => <h1> React time</h1>
// create file with component in it then export it to use elsewhere. 
export default Heading; 