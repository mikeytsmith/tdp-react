// const props = {name, age, specialism};

const ComponentWithProps = ({name, age, specialism}) => {
    return (
        <div> 
            <h1>{name}</h1>
            <p>{age}</p>
            <p>{specialism}</p>
            <p> colour</p>
        </div>

    )
}
export default ComponentWithProps;

// ComponentWithProps.propTypes = {
//     name: PropTypes.string.isRequired,
//     age: PropTypes.number.isRequired,
//     specialism: PropTypes.string.isRequired,
// };