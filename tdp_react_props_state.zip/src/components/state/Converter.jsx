import { useState } from "react";

const Converter = () => {

    const [miles,setMiles] = useState(0);
    const [kms, setKms] = useState(0);

    const updateMiles = (event) => {
        const newVal = parseInt(event.target.value);
        setMiles(newVal);
        setKms(newVal* 1.6);
    }

    return (
        <>
        {/* the parent tag or react fragment needed to make sure only calls one later */}
        <input type="number" value={miles} onChange={updateMiles}/>miles
        {
            miles === 500 && <p>And I would walk 500 more</p>
        }
        {/* this is how conditional rendering for loops are shown more common syntax 
        as one line instead of min 4 line if statemetn syntax. uses Java truthy falsey values
        if above miles value is exactly = to the number 500 then will display the additional message in the p tags */}
        <br/>
        <input type="number" value={kms}/>kms
        </>
    );
}
export default Converter;