import { useState } from "react";

const trainers = ["JH", "JB", "ER", "AS", "PB"];

function FilterableList() {
    // stores the empty search field state as a state so knows to action when this changes
    const [search, setSearch] = useState("");

    const filtered = [];

    for (let trainer of trainers) {
        if (trainer.toLowerCase().startsWith(search.toLowerCase())) filtered.push(trainer);
    }

    return (
    <div>
        <input type="text" value={search} onChange={(event) => setSearch(event.target.value)}/>
        <p>{filtered.join(",")}</p>
    </div>
    );
}
export default FilterableList;