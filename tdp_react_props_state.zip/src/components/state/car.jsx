import { useState } from "react";

const Car = () => {
    const [Brand, setBrand] = useState("BMW");
    const [Model, setModel] = useState("M4");
    const [Colour, setColour] = useState("Blue");
    const [Year, setYear] = useState("2020");

    const printValues = (event) => {
        event.preventDefault();
        console.log(Brand, Model, Colour, Year);
    };
    return(
        <>
            <h1> My car is a beaut.</h1>
            <h4> These are her features:</h4>
            <p> {Brand}, {Model}</p>
            <p>{Colour}</p>
            <p>{Year}</p>
            <form onSubmit={printValues}>
                <label> Car Brand: </label>
                <input name="brand"
                type="text"
                value={Brand}
                onChange={event => setBrand(event.target.value)}/>
                <br/>

                <label> Car Model: </label>
                <input name="model"
                type="text"
                value={Model}
                onChange={event => setModel(event.target.value)}/>
                <br/>

                <label> Car Colour: </label>
                <input name="colour"
                type="text"
                value={Colour}
                onChange={event => setColour(event.target.value)}/>
                <br/>

                <label> Car Year: </label>
                <input name="year"
                type="number"
                value={Year}
                onChange={event => setYear(event.target.value)}/>
                <br/>
                <button>Submit</button>
            </form>
        </>
    );
}
export default Car;
