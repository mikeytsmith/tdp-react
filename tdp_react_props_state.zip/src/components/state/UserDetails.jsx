import { useState } from "react";

const UserDetails = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const printValues = (event) => {
        event.preventDefault();
        console.log(username,password);
    };
    return(
        <>
            <form onSubmit={printValues}>
                <label> Username: </label>
                <input name="username"
                type="test"
                value={username}
                onChange={event => setUsername(event.target.value)}/>
                <br/>
                <label> Password: </label>
                <input type="password"
                name="password"
                value={password}
                onChange={event => setPassword(event.target.value)}/>
                <br/>
                <button>Submit</button>
            </form>
        </>
    );
}
export default UserDetails;