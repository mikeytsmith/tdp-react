import { useState } from "react";

const fruits = [ "Apple", "Banana", "Grape", "Strawberry" ];

const ProductTable = () => {
    const [search, setSearch] = useState("");
    const [result, setResult] = useState("");
    
    const searchBar = (event) => {
        setSearch(event.target.value);

        for (let fruit of fruits) {
            if (event.target.value === fruit) {
                return setResult(fruit);

            }
        }
        setResult("error");
    }
    return(
        <>

        <h2>Fruits:</h2>
        <p name="array">{fruits + ""}</p>

        
                <label> Fruit Search: </label>
                <input name="search"
                type="search"
                value={search}
                onChange={searchBar}/>
                <br/>

                <p>Result: {result}</p>
        </>
    );
}
export default ProductTable;