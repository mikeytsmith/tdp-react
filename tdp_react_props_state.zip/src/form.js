const Form = () => (
    <form>
        <label> Name:</label>
        <input type= "test"/>
        <label>Age:</label>
        <input type="number"/>
        <button type="buttin" onClick={() => ('yo!')}>Submit</button>

    </form>
)
export default Form;