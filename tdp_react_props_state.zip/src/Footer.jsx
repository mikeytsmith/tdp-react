const Footer = () => {
    return(
        <footer>
            <p><h1>this should be</h1></p>
            <p>the footer</p>
            <p>at the bottom</p>
            
        </footer>
    );
}


export default Footer;